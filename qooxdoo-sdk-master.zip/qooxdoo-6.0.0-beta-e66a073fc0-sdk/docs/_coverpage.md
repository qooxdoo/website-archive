![logo](_media/logo.svg)

> the javascript framework for coders

- rich widget set
- full class based oo
- multi language support
- powerful theming

[Get Started](#getting-started)

![color](#ffffff)
