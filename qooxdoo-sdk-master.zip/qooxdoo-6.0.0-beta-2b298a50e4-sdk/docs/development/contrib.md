# Qooxdoo package management

This page has [moved here](../cli/packages.md).
