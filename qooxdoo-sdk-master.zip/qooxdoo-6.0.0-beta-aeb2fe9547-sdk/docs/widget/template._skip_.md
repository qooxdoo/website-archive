Widget name
===========

**TODO:** *write some general stuff about the widget*

Preview Image
-------------

**TODO:** *one manually taken preview image of the widget*

Features
--------

-   **TODO:** *List of features (buzzwords)*

Description
-----------

**TODO:** *detailed information about the widget*

Diagram
-------

**TODO:** (if necessary) *a UML class diagram of the widget and its used classes using graphviz*

Demos
-----

Here are some links that demonstrate the usage of the widget:

-   [Meaningful name of the demo](http://demo.qooxdoo.org/%{version}/demobrowser/index.html#) **TODO:** set the link
-   **TODO:** *More than one demo possible ...*

API
---

Here is a link to the API of the Widget: [complete package and classname](http://demo.qooxdoo.org/%{version}/apiviewer/index.html#) **TODO:** set the link
