ThemedIframe
============

> **note**
>
> This widget is available since qooxdoo 0.8.3

Container widget for internal frames (iframes). An iframe can display any HTML page inside the widget.

Unlike `qx.ui.embed.Iframe`, which uses the browser's native iframe, ThemedIframe (particularly its scrollbars) can be visually modified according to the regular qooxdoo theming.
