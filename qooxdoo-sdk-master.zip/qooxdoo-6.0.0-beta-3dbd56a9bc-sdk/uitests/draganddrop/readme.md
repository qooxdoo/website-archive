# UI Tests

Until we have a working Selenium install, the tests you need to make are by compiling these apps and following instructions for each application below.  To compile and run the apps, just do:

```
$ qx serve
```

and open http://localhost:8080 


## Drag and Drop demo app (dragndrop/index.html)

Drag and drop items from Simple Source into Simple Target; make sure that when you switch on the checkboxes, you are able to prevent the drag and drop from happening

