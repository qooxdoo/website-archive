![logo](_media/logo.svg)

> the javascript framework for coders

- rich widget set
- full class based oo
- multi language support
- powerful theming

[About qooxdoo](about.md#about-qooxdoo)
[Get Started](#getting-started)
[Table of Contents](contents.md)

![color](#ffffff)
