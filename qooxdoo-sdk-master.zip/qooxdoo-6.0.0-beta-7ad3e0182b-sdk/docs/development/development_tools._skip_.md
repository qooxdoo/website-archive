Development Tools (outdated)
=================


TextMate
--------

There is up-to-date qooxdoo support for TextMate. Please see the [blog
post](http://news.qooxdoo.org/textmate-qooxdoo-bundle) .

Emacs
-----

[js2-mode](http://code.google.com/p/js2-mode/) offers improved JavaScript
support in Emacs. While it doesn't include qooxdoo-specific support, it
eventually aims to be competitive with other best-of-class JavaScript editors.
Also see the original [blog
post](http://steve-yegge.blogspot.com/2008/03/js2-mode-new-javascript-mode-for-emacs.html).
