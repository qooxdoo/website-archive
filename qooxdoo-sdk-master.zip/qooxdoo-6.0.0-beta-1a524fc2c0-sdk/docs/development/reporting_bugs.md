Reporting Bugs
==============

> **note**
>
> Please see the general document on [How to report bugs](http://qooxdoo.org/community/bugs)
